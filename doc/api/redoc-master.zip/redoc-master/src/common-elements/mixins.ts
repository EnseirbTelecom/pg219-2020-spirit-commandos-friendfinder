import { css } from '../styled-components';

export const deprecatedCss = css`
  text-decoration: line-through;
  color: #bdccd3;
`;
